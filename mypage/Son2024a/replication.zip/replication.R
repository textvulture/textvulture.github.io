# Replication for Son (2024) "Consequences of Democratic Backsliding in Popular culture" Democratization. Journal Link: https://www.tandfonline.com/doi/full/10.1080/13510347.2024.2343103

library(dplyr)
library(modelsummary)
library(kableExtra)
library(ggplot2)
library(fixest)
library(ggiplot)


#####

### the primary regression table

data <- readRDS("data.rds")

model1 <- feols(lncount ~ treatment*shock2012 + factor(year),
                data=data,
                panel.id = ~id+year, 
                fixef = c("id", "role"), 
                cluster=c("id"))


model2 <- feols(lncount ~ treatment*shock2012 + cumu + lncareer + 
                  factor(year),
                data=data,
                panel.id = ~id+year, 
                fixef = c("id", "role"), 
                cluster=c("id"))

actor <- feols(lncount ~ treatment*shock2012 + cumu + lncareer + 
                 factor(year),
               data=data %>%
                 filter(actor==0),
               panel.id = ~id+year, 
               fixef = c("id", "role"), 
               cluster=c("id"))



### the reg table

table2 <- list("Baseline" = model1,
               "Benchmark"  = model2,
               "Non-actor" = actor)

relabel <- c("treatment:shock2012" = "Blacklisted $\\times$ Treatment",
             "shock2012" = "Treatment",
             "treatment" = "Blacklisted",
             "cumu" = "ln(number of movies + 1)",
             "lncareer" = "ln(years since debut + 1)"
)

FE <- data.frame("Coefficients" = c("Unit Fixed", "Year Fixed", "Role Fixed"),
                 "Baseline" = c("$\\checkmark$", "$\\checkmark$", " "),
                 "Benchmark" = c("$\\checkmark$", "$\\checkmark$", "$\\checkmark$"),
                 "Non-actor" = c("$\\checkmark$", "$\\checkmark$", "$\\checkmark$")
)	

modelsummary(table2, 
             escape = F,
             coef_map = relabel,
             coef_omit = "[^shock2012|treatment|treatment:shock2012|cumu|lncareer]",
             stars =  c('*' = .1, '**' = .05, '***' = 0.01),
             fmt = 3,
             threeparttable = T,
             gof_omit = 'DF|R2 Adj.|Std.Errors|R2 Pseudo|R2 Within|[FE]',
             title = 'Benchmark Difference-in-Difference Estimates',
             add_rows = FE,
             notes = "OLS estimates  with standard errors clustered over unit. Fixed effect results are abbreviated to spare space"
) %>% add_header_above(c(" ", "(1)", "(2)", "(3)")
)

## Event Study Graphs

event <- feols(lncount ~ lncareer + cumu + factor(role) + 
                 i(year, treatment, ref=2012) | id+year, data)
ggiplot(event,
        #color='red',
        main=" ", # The effect of Blacklist on Movie Workers' Career 
        ref=FALSE) +
  theme_minimal() +
  labs(x="Year",
       y="Treatment Effect (95% CI)") 

event2 <- feols(lncount ~ lncareer + cumu + factor(role) + 
                  i(year, treatment, ref=2012) | id+year, data %>%
                  filter(actor==0))
ggiplot(event2,
        color='red',
        main=" ", # The effect of Blacklist on Movie Workers' Career 
        ref=FALSE) +
  theme_minimal() +
  labs(x="Year",
       y="Treatment Effect (95% CI)") 

